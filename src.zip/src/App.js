import "./App.css";
import { Outlet, Link, useLocation } from "react-router-dom";
import { useEffect } from "react";
function App() {
  let location = useLocation();
  useEffect(() => {
    console.log(location);
  }, [location]);
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/classcomponent">UsingClassComponent</Link>
          </li>
          <li>
            <Link to="/Multiplevaluecheckbox" className="active">
              Multiplevaluecheckbox
            </Link>
          </li>
          <li>
            <Link to="/Changekeyvalue">Changekeyvalue</Link>
          </li>
        </ul>
      </nav>

      <Outlet />
    </>
  );
}
export default App;
